self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "707989cd46d679857c12c3fb222a3c6e",
    "url": "/yoyoo/index.html"
  },
  {
    "revision": "e52b775cdb037c0f9d86",
    "url": "/yoyoo/static/css/2.8a0fc0e9.chunk.css"
  },
  {
    "revision": "dd75ff323a458c9067f4",
    "url": "/yoyoo/static/css/main.b02e0cab.chunk.css"
  },
  {
    "revision": "e52b775cdb037c0f9d86",
    "url": "/yoyoo/static/js/2.06c2bb6b.chunk.js"
  },
  {
    "revision": "46ec4611a47c15d64bf42dd362f011bb",
    "url": "/yoyoo/static/js/2.06c2bb6b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "dd75ff323a458c9067f4",
    "url": "/yoyoo/static/js/main.002a287f.chunk.js"
  },
  {
    "revision": "2597becaa8a65f4e7260",
    "url": "/yoyoo/static/js/runtime-main.5bbfd879.js"
  },
  {
    "revision": "b10962a4f4fa7e86efa04bc9cbc29b70",
    "url": "/yoyoo/static/media/default_avatar.b10962a4.svg"
  },
  {
    "revision": "6e3e46324506fa331616651ffcba3924",
    "url": "/yoyoo/static/media/head.6e3e4632.jpg"
  },
  {
    "revision": "2eeead6099834eae5896d58ef521073b",
    "url": "/yoyoo/static/media/iconfont.2eeead60.woff"
  },
  {
    "revision": "35e310d875295020a53cc701154bccf0",
    "url": "/yoyoo/static/media/iconfont.35e310d8.svg"
  },
  {
    "revision": "41266eafaace323d310f6f9e00de0a05",
    "url": "/yoyoo/static/media/iconfont.41266eaf.eot"
  },
  {
    "revision": "a80ace1a547b421333a53cd7ad1df387",
    "url": "/yoyoo/static/media/iconfont.a80ace1a.eot"
  },
  {
    "revision": "a8b64538e515d7541f9e26eb14d847ff",
    "url": "/yoyoo/static/media/iconfont.a8b64538.ttf"
  },
  {
    "revision": "ba1167e4fb2ba298b46f62b80a1106fa",
    "url": "/yoyoo/static/media/iconfont.ba1167e4.ttf"
  },
  {
    "revision": "c6e7745f807e7439d9e8fb600dddca41",
    "url": "/yoyoo/static/media/iconfont.c6e7745f.woff"
  },
  {
    "revision": "dcbf36c4d1fd3809a8cb68b3a5bcc45b",
    "url": "/yoyoo/static/media/iconfont.dcbf36c4.svg"
  },
  {
    "revision": "60e542768b2b978ceb36c4ef4dc1d6de",
    "url": "/yoyoo/static/media/no_project.60e54276.png"
  },
  {
    "revision": "66cd5f82ce4ca4526e2740e564c7d13f",
    "url": "/yoyoo/static/media/sb.66cd5f82.png"
  },
  {
    "revision": "da0be9f8c183ad568bfa9d64b4e119a0",
    "url": "/yoyoo/static/media/ucenter_banner.da0be9f8.png"
  }
]);